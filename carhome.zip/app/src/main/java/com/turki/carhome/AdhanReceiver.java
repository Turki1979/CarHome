package com.turki.carhome;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** يستقبل منبّه وقت الصلاة (وتشغيل الجهاز) ويشغّل الأذان ثم يجدول اللي بعده. */
public class AdhanReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context c, Intent intent) {
        String action = intent.getAction();
        if ("com.turki.carhome.ADHAN".equals(action) && AdhanScheduler.isOn(c)) {
            Intent s = new Intent(c, AdhanService.class);
            s.putExtra("name", intent.getStringExtra("name"));
            try {
                c.startForegroundService(s);
            } catch (Exception ignored) {
            }
        }
        AdhanScheduler.schedule(c);
    }
}
