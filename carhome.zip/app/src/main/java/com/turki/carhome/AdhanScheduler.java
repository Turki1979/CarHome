package com.turki.carhome;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.util.Calendar;
import java.util.TimeZone;

/** يجدول منبّه الأذان القادم (يشتغل حتى لو الواجهة مو ظاهرة). */
final class AdhanScheduler {

    static final String[] NAMES = {"الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء"};
    private static final int[] PRAYERS = {0, 2, 3, 4, 5};
    private static final int REQ = 100;

    private AdhanScheduler() {}

    static boolean isOn(Context c) {
        return AppsHelper.prefs(c).getBoolean("adhanOn", true);
    }

    static void setOn(Context c, boolean on) {
        AppsHelper.prefs(c).edit().putBoolean("adhanOn", on).apply();
        schedule(c);
    }

    private static PendingIntent pending(Context c, String name) {
        Intent i = new Intent(c, AdhanReceiver.class);
        i.setAction("com.turki.carhome.ADHAN");
        if (name != null) i.putExtra("name", name);
        return PendingIntent.getBroadcast(c, REQ, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static boolean isRamadan(Calendar day) {
        try {
            android.icu.util.IslamicCalendar ic = new android.icu.util.IslamicCalendar();
            ic.setCalculationType(android.icu.util.IslamicCalendar.CalculationType.ISLAMIC_UMALQURA);
            ic.setTime(day.getTime());
            return ic.get(android.icu.util.Calendar.MONTH) == 8;
        } catch (Exception e) {
            return false;
        }
    }

    static double[] timesFor(Context c, Calendar day) {
        SharedPreferences p = AppsHelper.prefs(c);
        double lat = Double.parseDouble(p.getString("lat", "21.5433"));
        double lng = Double.parseDouble(p.getString("lng", "39.1728"));
        double tz = TimeZone.getDefault().getOffset(day.getTimeInMillis()) / 3600000.0;
        return PrayerTimes.compute(day.get(Calendar.YEAR), day.get(Calendar.MONTH) + 1,
                day.get(Calendar.DAY_OF_MONTH), lat, lng, tz, isRamadan(day));
    }

    static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        if (!isOn(c)) {
            am.cancel(pending(c, null));
            return;
        }
        long now = System.currentTimeMillis();
        for (int d = 0; d < 2; d++) {
            Calendar day = Calendar.getInstance();
            day.add(Calendar.DAY_OF_MONTH, d);
            double[] t = timesFor(c, day);
            for (int i : PRAYERS) {
                Calendar at = (Calendar) day.clone();
                at.set(Calendar.HOUR_OF_DAY, 0);
                at.set(Calendar.MINUTE, 0);
                at.set(Calendar.SECOND, 0);
                at.set(Calendar.MILLISECOND, 0);
                at.add(Calendar.MINUTE, (int) Math.round(t[i] * 60));
                if (at.getTimeInMillis() > now + 30000) {
                    setAlarm(am, at.getTimeInMillis(), pending(c, NAMES[i]));
                    return;
                }
            }
        }
    }

    private static void setAlarm(AlarmManager am, long when, PendingIntent pi) {
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }
}
