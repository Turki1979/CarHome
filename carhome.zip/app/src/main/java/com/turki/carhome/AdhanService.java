package com.turki.carhome;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.IBinder;

/** يشغّل صوت الأذان ويوقّف الموسيقى مؤقتاً، ويقدر يتوقف من الإشعار أو من الواجهة. */
public class AdhanService extends Service {

    static final String ACTION_STOP = "com.turki.carhome.STOP_ADHAN";
    private static final String CHANNEL = "adhan";

    private MediaPlayer mp;
    private AudioManager audio;
    private AudioFocusRequest focus;

    static void stop(Context c) {
        Intent i = new Intent(c, AdhanService.class);
        i.setAction(ACTION_STOP);
        try {
            c.startService(i);
        } catch (Exception ignored) {
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        String name = intent != null ? intent.getStringExtra("name") : null;
        startForeground(1, buildNotification(name));
        play();
        return START_NOT_STICKY;
    }

    private Notification buildNotification(String name) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "تنبيه الصلاة",
                NotificationManager.IMPORTANCE_LOW));
        Intent stop = new Intent(this, AdhanService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String title = name != null ? "حان الآن وقت صلاة " + name : "تنبيه الصلاة";
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle(title)
                .setContentText("تنبيه دخول وقت الصلاة")
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "إيقاف", stopPi).build())
                .build();
    }

    private void play() {
        releasePlayer();
        // صوت تنبيه الإشعارات الافتراضي في الجهاز
        Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);

        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
        audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        focus = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(attrs)
                .build();
        try {
            audio.requestAudioFocus(focus);
        } catch (Exception ignored) {
        }

        try {
            mp = new MediaPlayer();
            mp.setAudioAttributes(attrs);
            mp.setDataSource(this, uri);
            mp.setOnPreparedListener(MediaPlayer::start);
            mp.setOnCompletionListener(m -> stopSelf());
            mp.setOnErrorListener((m, w, e) -> {
                stopSelf();
                return true;
            });
            mp.prepareAsync();
        } catch (Exception e) {
            stopSelf();
        }
    }

    private void releasePlayer() {
        if (mp != null) {
            try {
                mp.stop();
            } catch (Exception ignored) {
            }
            mp.release();
            mp = null;
        }
    }

    @Override
    public void onDestroy() {
        releasePlayer();
        if (audio != null && focus != null) {
            try {
                audio.abandonAudioFocusRequest(focus);
            } catch (Exception ignored) {
            }
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
