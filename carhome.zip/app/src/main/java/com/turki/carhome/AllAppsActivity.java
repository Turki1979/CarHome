package com.turki.carhome;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AllAppsActivity extends Activity {

    private static class AppItem {
        String pkg;
        String cls;
        String label;
        ResolveInfo ri;
    }

    private final List<AppItem> apps = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(0xFF0A1424);
        int pad = AppsHelper.dp(this, 16);
        root.setPadding(pad, pad, pad, pad);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("كل التطبيقات  •  اضغط مطوّلاً لإضافة التطبيق للمفضلة");
        title.setTextColor(0xFF9FB2CC);
        title.setTextSize(15);
        header.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        TextView back = new TextView(this);
        back.setText("رجوع");
        back.setTextColor(0xFF5FA8FF);
        back.setTextSize(15);
        back.setBackgroundResource(R.drawable.item_bg);
        int bp = AppsHelper.dp(this, 8);
        back.setPadding(bp * 2, bp, bp * 2, bp);
        back.setOnClickListener(v -> finish());
        header.addView(back);

        root.addView(header);

        GridView grid = new GridView(this);
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setColumnWidth(AppsHelper.dp(this, 112));
        grid.setVerticalSpacing(AppsHelper.dp(this, 10));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
        glp.topMargin = AppsHelper.dp(this, 12);
        root.addView(grid, glp);

        setContentView(root);

        loadApps();

        grid.setAdapter(new BaseAdapter() {
            @Override
            public int getCount() { return apps.size(); }

            @Override
            public Object getItem(int i) { return apps.get(i); }

            @Override
            public long getItemId(int i) { return i; }

            @Override
            public View getView(int i, View convert, ViewGroup parent) {
                AppItem a = apps.get(i);
                PackageManager pm = getPackageManager();
                LinearLayout v = AppsHelper.makeAppView(AllAppsActivity.this, a.ri.loadIcon(pm), a.label);
                v.setClickable(false);
                v.setFocusable(false);
                return v;
            }
        });

        grid.setOnItemClickListener((parent, view, pos, id) -> {
            AppItem a = apps.get(pos);
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_LAUNCHER);
            i.setComponent(new ComponentName(a.pkg, a.cls));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            try {
                startActivity(i);
            } catch (Exception e) {
                AppsHelper.launch(this, a.pkg);
            }
        });

        grid.setOnItemLongClickListener((parent, view, pos, id) -> {
            AppItem a = apps.get(pos);
            boolean added = AppsHelper.addFav(this, a.pkg);
            Toast.makeText(this, added ? "تمت إضافة " + a.label + " للمفضلة" : a.label + " موجود بالمفضلة",
                    Toast.LENGTH_SHORT).show();
            return true;
        });
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
        for (ResolveInfo ri : list) {
            if (ri.activityInfo == null) continue;
            if (getPackageName().equals(ri.activityInfo.packageName)) continue;
            AppItem a = new AppItem();
            a.pkg = ri.activityInfo.packageName;
            a.cls = ri.activityInfo.name;
            a.label = String.valueOf(ri.loadLabel(pm));
            a.ri = ri;
            apps.add(a);
        }
        Collections.sort(apps, (x, y) -> x.label.compareToIgnoreCase(y.label));
    }
}
