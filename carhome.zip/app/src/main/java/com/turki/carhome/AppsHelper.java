package com.turki.carhome;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

final class AppsHelper {

    /** التطبيقات المفضلة الافتراضية (يظهر منها المثبّت فقط) */
    static final String[] DEFAULT_FAVS = {
            "com.waze",
            "com.google.android.apps.maps",
            "com.google.android.youtube",
            "com.spotify.music",
            "com.google.android.apps.youtube.music",
            "com.ovz.carscanner",
            "org.prowl.torque",
            "com.android.chrome"
    };

    private AppsHelper() {}

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("carhome", Context.MODE_PRIVATE);
    }

    static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static List<String> getFavs(Context c) {
        String s = prefs(c).getString("favs", null);
        List<String> out = new ArrayList<>();
        if (s == null) {
            PackageManager pm = c.getPackageManager();
            for (String p : DEFAULT_FAVS) {
                if (pm.getLaunchIntentForPackage(p) != null) out.add(p);
            }
        } else {
            for (String p : s.split(",")) {
                if (!p.isEmpty()) out.add(p);
            }
        }
        return out;
    }

    static void saveFavs(Context c, List<String> favs) {
        prefs(c).edit().putString("favs", TextUtils.join(",", favs)).apply();
    }

    static boolean addFav(Context c, String pkg) {
        List<String> favs = getFavs(c);
        if (favs.contains(pkg)) return false;
        favs.add(pkg);
        saveFavs(c, favs);
        return true;
    }

    static void removeFav(Context c, String pkg) {
        List<String> favs = getFavs(c);
        favs.remove(pkg);
        saveFavs(c, favs);
    }

    /** يدوّر على تطبيق مثبّت باسمه أو اسم حزمته (مثلاً هدهد) */
    static String findApp(Context c, String... keys) {
        PackageManager pm = c.getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        for (android.content.pm.ResolveInfo ri : pm.queryIntentActivities(main, 0)) {
            String pkg = ri.activityInfo.packageName.toLowerCase(java.util.Locale.US);
            String label = String.valueOf(ri.loadLabel(pm)).toLowerCase(java.util.Locale.US);
            for (String k : keys) {
                String kk = k.toLowerCase(java.util.Locale.US);
                if (pkg.contains(kk) || label.contains(kk)) return ri.activityInfo.packageName;
            }
        }
        return null;
    }

    static String hudhud(Context c) {
        return findApp(c, "hudhud", "هدهد");
    }

    static void launch(Context c, String pkg) {
        Intent i = c.getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) {
            Toast.makeText(c, "التطبيق غير مثبّت", Toast.LENGTH_SHORT).show();
            return;
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            c.startActivity(i);
        } catch (Exception e) {
            Toast.makeText(c, "تعذّر فتح التطبيق", Toast.LENGTH_SHORT).show();
        }
    }

    static LinearLayout makeAppView(Context c, Drawable icon, CharSequence label) {
        LinearLayout ll = new LinearLayout(c);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.setGravity(Gravity.CENTER);
        int p = dp(c, 8);
        ll.setPadding(p, p, p, p);
        ll.setBackgroundResource(R.drawable.item_bg);
        ll.setClickable(true);
        ll.setFocusable(true);

        ImageView iv = new ImageView(c);
        iv.setImageDrawable(icon);
        ll.addView(iv, new LinearLayout.LayoutParams(dp(c, 56), dp(c, 56)));

        TextView tv = new TextView(c);
        tv.setText(label);
        tv.setTextColor(0xFFEEF3FA);
        tv.setTextSize(13);
        tv.setSingleLine(true);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        tv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(c, 96),
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(c, 4);
        ll.addView(tv, lp);
        return ll;
    }
}
