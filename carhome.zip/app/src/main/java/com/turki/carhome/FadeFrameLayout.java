package com.turki.carhome;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.widget.FrameLayout;

/** حاوية تخلّي أطراف المحتوى (الخريطة) تتلاشى بشكل بيضاوي وتندمج مع الخلفية. */
public class FadeFrameLayout extends FrameLayout {

    private final Paint maskPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public FadeFrameLayout(Context c) {
        this(c, null);
    }

    public FadeFrameLayout(Context c, AttributeSet a) {
        super(c, a);
        setWillNotDraw(false);
        maskPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w == 0 || h == 0) return;
        RadialGradient g = new RadialGradient(w / 2f, h / 2f, w / 2f,
                new int[]{0xFF000000, 0xFF000000, 0x00000000},
                new float[]{0f, 0.5f, 1f},
                Shader.TileMode.CLAMP);
        Matrix m = new Matrix();
        m.setScale(1f, (float) h / w, w / 2f, h / 2f);
        g.setLocalMatrix(m);
        maskPaint.setShader(g);
    }

    @Override
    protected void dispatchDraw(Canvas canvas) {
        int sc = canvas.saveLayer(0, 0, getWidth(), getHeight(), null);
        super.dispatchDraw(canvas);
        canvas.drawRect(0, 0, getWidth(), getHeight(), maskPaint);
        canvas.restoreToCount(sc);
    }
}
