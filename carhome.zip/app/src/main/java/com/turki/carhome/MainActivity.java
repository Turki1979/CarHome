package com.turki.carhome;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.widget.FrameLayout;
import android.widget.TextView;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import org.json.JSONArray;
import org.json.JSONObject;
import org.maplibre.android.MapLibre;
import org.maplibre.android.camera.CameraPosition;
import org.maplibre.android.camera.CameraUpdateFactory;
import org.maplibre.android.geometry.LatLng;
import org.maplibre.android.maps.MapLibreMap;
import org.maplibre.android.maps.MapLibreMapOptions;
import org.maplibre.android.maps.MapView;
import org.maplibre.android.maps.Style;
import org.maplibre.android.style.expressions.Expression;
import org.maplibre.android.style.layers.FillExtrusionLayer;
import org.maplibre.android.style.layers.PropertyFactory;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements NavNotificationService.Listener {

    private static final int REQ_PERMS = 1;
    private static final Locale AR = new Locale("ar");

    private TextView tvMin;
    private TextView tvDay, tvTime, tvDate, tvNextName, tvNextTime, tvNextLeft;
    private static final String[] NAMES = {"الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء"};
    private double[] times;
    private String timesKey = "";
    private static final String STYLE_URL = "https://tiles.openfreemap.org/styles/fiord";
    private MapView mapView;
    private MapLibreMap map;
    private double lastBearing = 0;
    private TextView tvSpeed, tvLimit;
    private Location lastLimitCheck;
    private long lastLimitTime;
    private volatile boolean limitBusy;
    private android.media.ToneGenerator tone;
    private WeatherView weather;
    private PhotoSlideshow slideshow;
    private TextView tvCam;
    private LinearLayout navBanner;
    private ImageView navIcon;
    private TextView navTitle, navText, navDist;
    private View navFill;
    private FrameLayout navTrack;
    private String navKey = "";
    private float navStartM = 0;
    private int hudhudLimit = 0;
    private String lastNavAlertKey = "";
    private final java.util.List<double[]> cameras = new java.util.ArrayList<>();
    private final java.util.Map<String, Long> camAlerted = new java.util.HashMap<>();
    private Location lastCamFetch;
    private long lastCamFetchTime;
    private volatile boolean camBusy;
    private static final int REQ_PHOTOS = 7;
    private long lastWeather;
    private final Runnable weatherTick = new Runnable() {
        @Override
        public void run() {
            fetchWeather();
            handler.postDelayed(this, 15 * 60 * 1000);
        }
    };
    private long lastBeep;
    private LocationManager lm;
    private boolean locationStarted;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateClock();
            handler.postDelayed(this, 1000);
        }
    };

    private final LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location l) {
            onNewLocation(l);
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        MapLibre.getInstance(this);

        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float ratio = (float) Math.max(dm.widthPixels, 1) / Math.max(dm.heightPixels, 1);
        // شاشة عريضة → الترتيب العرضي، شاشة مربعة أو طولية → الترتيب المربع
        setContentView(ratio >= 1.45f ? R.layout.activity_main : R.layout.activity_main_square);
        tvDay = findViewById(R.id.tvDay);
        tvTime = findViewById(R.id.tvTime);
        tvDate = findViewById(R.id.tvDate);
        tvNextName = findViewById(R.id.tvNextName);
        tvNextTime = findViewById(R.id.tvNextTime);
        tvNextLeft = findViewById(R.id.tvNextLeft);
        tvNextTime.setVisibility(View.GONE); // نعرض الاسم وكم باقي بس
        tvDay.setVisibility(View.GONE);
        tvDate.setVisibility(View.GONE);
        tvMin = findViewById(R.id.tvMin);
        if (tvMin != null) setupStackedClock();
        FrameLayout wh = findViewById(R.id.weatherHolder);
        if (wh != null) {
            if (wh instanceof FadeFrameLayout) {
                View glow = new View(this);
                glow.setBackgroundColor(0xFF1A3358); // يتلاشى من الأطراف مع الحاوية
                wh.addView(glow, new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            }
            weather = new WeatherView(this);
            wh.addView(weather, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        }

        findViewById(R.id.btnApps).setOnClickListener(v ->
                startActivity(new Intent(this, AllAppsActivity.class)));
        findViewById(R.id.root).setOnLongClickListener(v -> {
            startActivity(new Intent(this, AllAppsActivity.class));
            return true;
        });

        findViewById(R.id.prayerBox).setOnClickListener(v -> showPrayerAlertDialog());
        setupMap(savedInstanceState);
        addAttribution();
        addSpeedViews();
        addSlideshow();
        addNavBanner();
        requestPerms();
        AdhanScheduler.schedule(this);
        maybeAutoStartHudhud();
    }

    /** أول ما يشتغل الجهاز: نفتح هدهد (لتنبيهات الكاميرات) ونرجع للواجهة */
    private void maybeAutoStartHudhud() {
        if (!AppsHelper.prefs(this).getBoolean("autoHudhud", true)) return;
        // وقت تشغيل الجهاز: إذا نفسه المحفوظ يعني هدهد سبق وانفتح في هذا التشغيل
        long now = System.currentTimeMillis() - android.os.SystemClock.elapsedRealtime();
        long last = AppsHelper.prefs(this).getLong("hudhudAt", 0);
        if (Math.abs(now - last) < 60000) return;
        final String hh = AppsHelper.hudhud(this);
        if (hh == null) return;
        AppsHelper.prefs(this).edit().putLong("hudhudAt", now).apply();
        handler.postDelayed(() -> {
            AppsHelper.launch(this, hh);
            handler.postDelayed(() -> {
                Intent back = new Intent(this, MainActivity.class);
                back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                try {
                    startActivity(back);
                } catch (Exception ignored) {
                }
            }, 7000);
        }, 3000);
    }

    /** صور تتبدل تحت يمين، مقابل زر التطبيقات. ضغط مطوّل لاختيار الصور من الجهاز. */
    private void addSlideshow() {
        slideshow = new PhotoSlideshow(this);
        FrameLayout ph = findViewById(R.id.photoHolder);
        if (ph != null) {
            ph.addView(slideshow, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        } else {
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    AppsHelper.dp(this, 150), AppsHelper.dp(this, 200), Gravity.BOTTOM | Gravity.RIGHT);
            lp.rightMargin = AppsHelper.dp(this, 8);
            lp.bottomMargin = AppsHelper.dp(this, 8);
            ((FrameLayout) findViewById(R.id.root)).addView(slideshow, lp);
        }
        slideshow.setOnLongClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            try {
                startActivityForResult(i, REQ_PHOTOS);
            } catch (Exception e) {
                android.widget.Toast.makeText(this, "ما لقيت تطبيق لاختيار الصور", android.widget.Toast.LENGTH_LONG).show();
            }
            return true;
        });
        slideshow.setPhotos(loadPhotoUris());
    }

    private java.util.List<android.net.Uri> loadPhotoUris() {
        java.util.List<android.net.Uri> out = new java.util.ArrayList<>();
        String saved = AppsHelper.prefs(this).getString("photos", "");
        for (String s : saved.split("\n")) {
            if (!s.isEmpty()) out.add(android.net.Uri.parse(s));
        }
        return out;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PHOTOS || resultCode != RESULT_OK || data == null) return;
        java.util.List<android.net.Uri> uris = new java.util.ArrayList<>();
        if (data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                uris.add(data.getClipData().getItemAt(i).getUri());
            }
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        StringBuilder sb = new StringBuilder();
        for (android.net.Uri u : uris) {
            try {
                getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            sb.append(u.toString()).append("\n");
        }
        AppsHelper.prefs(this).edit().putString("photos", sb.toString()).apply();
        slideshow.setPhotos(uris);
    }

    /** ساعة فوق دقايق، حجمها نسبة من ارتفاع الشاشة، والدقايق تتلاشى في الخريطة */
    private void setupStackedClock() {
        float h = getResources().getDisplayMetrics().heightPixels;
        float px = h * 0.2f;
        tvTime.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, px);
        tvMin.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, px);
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) tvMin.getLayoutParams();
        lp.topMargin = -Math.round(px * 0.06f);
        tvMin.setLayoutParams(lp);
        tvMin.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            int vh = b - t;
            if (vh <= 0) return;
            tvMin.getPaint().setShader(new android.graphics.LinearGradient(0, 0, 0, vh,
                    new int[]{0xFFEEF3FA, 0xB3EEF3FA, 0x0DEEF3FA},
                    new float[]{0f, 0.5f, 1f}, android.graphics.Shader.TileMode.CLAMP));
            tvMin.invalidate();
        });
    }

    /** الطقس الحالي من Open-Meteo (مجاني بدون مفتاح) */
    private void fetchWeather() {
        if (weather == null) return;
        lastWeather = System.currentTimeMillis();
        final double lat = Double.parseDouble(AppsHelper.prefs(this).getString("lat", "21.5433"));
        final double lng = Double.parseDouble(AppsHelper.prefs(this).getString("lng", "39.1728"));
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                String url = String.format(Locale.US,
                        "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f"
                                + "&current=temperature_2m,weather_code,is_day&timezone=auto", lat, lng);
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(8000);
                c.setReadTimeout(8000);
                StringBuilder sb = new StringBuilder();
                try (InputStream is = c.getInputStream()) {
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = is.read(buf)) > 0) sb.append(new String(buf, 0, n, "UTF-8"));
                }
                JSONObject cur = new JSONObject(sb.toString()).getJSONObject("current");
                final double temp = cur.getDouble("temperature_2m");
                final int code = cur.getInt("weather_code");
                final boolean isDay = cur.optInt("is_day", 1) == 1;
                runOnUiThread(() -> weather.setWeather(code, isDay, temp));
            } catch (Exception ignored) {
                lastWeather = 0; // نعيد المحاولة مع أول تحديث موقع
            } finally {
                if (c != null) c.disconnect();
            }
        }).start();
    }

    /** الضغط على الصلاة القادمة: تشغيل/إيقاف التنبيه وتجربته */
    private void showPrayerAlertDialog() {
        boolean on = AdhanScheduler.isOn(this);
        boolean speedOn = AppsHelper.prefs(this).getBoolean("speedAlertOn", true);
        boolean autoHh = AppsHelper.prefs(this).getBoolean("autoHudhud", true);
        boolean camOn = AppsHelper.prefs(this).getBoolean("camAlertOn", true);
        String[] items = {
                on ? "إيقاف تنبيه الصلاة" : "تشغيل تنبيه الصلاة",
                "تجربة تنبيه الصلاة",
                speedOn ? "إيقاف تنبيه السرعة" : "تشغيل تنبيه السرعة",
                "تجربة تنبيه السرعة",
                autoHh ? "إيقاف فتح هدهد تلقائياً" : "تشغيل فتح هدهد تلقائياً",
                camOn ? "إيقاف تنبيه الكاميرات (الاحتياطي)" : "تشغيل تنبيه الكاميرات (الاحتياطي)",
                "تجربة تنبيه الكاميرا",
                "حد السرعة الاحتياطي: " + (AppsHelper.prefs(this).getInt("fallbackLimit", 120) > 0
                        ? AppsHelper.prefs(this).getInt("fallbackLimit", 120) : "بدون")
        };
        new android.app.AlertDialog.Builder(this)
                .setTitle("التنبيهات")
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        AdhanScheduler.setOn(this, !on);
                    } else if (which == 1) {
                        Intent i = new Intent(this, AdhanService.class);
                        i.putExtra("name", tvNextName.getText().toString());
                        startForegroundService(i);
                    } else if (which == 2) {
                        AppsHelper.prefs(this).edit().putBoolean("speedAlertOn", !speedOn).apply();
                    } else if (which == 3) {
                        speedBeep();
                    } else if (which == 4) {
                        AppsHelper.prefs(this).edit().putBoolean("autoHudhud", !autoHh).apply();
                    } else if (which == 5) {
                        AppsHelper.prefs(this).edit().putBoolean("camAlertOn", !camOn).apply();
                    } else if (which == 6) {
                        cameraBeep();
                    } else if (which == 7) {
                        chooseFallbackLimit();
                    } else {
                        openNotificationAccess();
                    }
                })
                .show();
    }

    /** صوت تنبيه السرعة: بيب مزدوج مختلف عن صوت الإشعارات */
    private void speedBeep() {
        try {
            if (tone == null) {
                tone = new android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 100);
            }
            tone.startTone(android.media.ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 900);
        } catch (Exception ignored) {
        }
    }

    private void setupMap(Bundle savedInstanceState) {
        FrameLayout holder = findViewById(R.id.mapHolder);
        MapLibreMapOptions opts = MapLibreMapOptions.createFromAttributes(this)
                .textureMode(true);
        mapView = new MapView(this, opts);
        mapView.onCreate(savedInstanceState);
        holder.addView(mapView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // سهم السيارة في نص الخريطة (الخريطة تلف مع الاتجاه فالسهم دايماً لفوق)
        ImageView arrow = new ImageView(this);
        arrow.setImageBitmap(makeArrow(AppsHelper.dp(this, 34)));
        holder.addView(arrow, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        // طبقة شفافة: الضغط على الخريطة يفتح الملاحة
        View touch = new View(this);
        touch.setOnClickListener(v -> openNavigation());
        holder.addView(touch, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        mapView.getMapAsync(m -> {
            map = m;
            map.getUiSettings().setAllGesturesEnabled(false);
            map.getUiSettings().setCompassEnabled(false);
            map.getUiSettings().setLogoEnabled(false);
            map.getUiSettings().setAttributionEnabled(false);
            double lat = Double.parseDouble(AppsHelper.prefs(this).getString("lat", "21.5433"));
            double lng = Double.parseDouble(AppsHelper.prefs(this).getString("lng", "39.1728"));
            map.setCameraPosition(new CameraPosition.Builder()
                    .target(new LatLng(lat, lng)).zoom(16.5).tilt(55).bearing(0).build());
            map.setStyle(new Style.Builder().fromUri(STYLE_URL), this::add3dBuildings);
        });
    }

    /** مبانٍ مجسّمة بارتفاعها الحقيقي */
    private void add3dBuildings(Style style) {
        // خلفية الخريطة بنفس كحلي الواجهة عشان ما يطلع شكل بيضاوي رمادي
        try {
            for (org.maplibre.android.style.layers.Layer layer : style.getLayers()) {
                if (layer instanceof org.maplibre.android.style.layers.BackgroundLayer) {
                    layer.setProperties(PropertyFactory.backgroundColor("#0F1D33"));
                }
            }
        } catch (Exception ignored) {
        }
        try {
            if (style.getSource("openmaptiles") == null) return;
            FillExtrusionLayer b = new FillExtrusionLayer("carhome-3d", "openmaptiles");
            b.setSourceLayer("building");
            b.setMinZoom(14f);
            b.setProperties(
                    PropertyFactory.fillExtrusionColor("#2A4A78"),
                    PropertyFactory.fillExtrusionHeight(Expression.get("render_height")),
                    PropertyFactory.fillExtrusionBase(Expression.get("render_min_height")),
                    PropertyFactory.fillExtrusionOpacity(0.85f));
            style.addLayer(b);
        } catch (Exception ignored) {
        }
    }

    private void addAttribution() {
        TextView t = new TextView(this);
        t.setText("© OpenFreeMap © OpenMapTiles © OpenStreetMap");
        t.setTextSize(9);
        t.setTextColor(0x999FB2CC);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.END);
        int m = AppsHelper.dp(this, 8);
        lp.setMargins(m, m, m, m);
        ((FrameLayout) findViewById(R.id.root)).addView(t, lp);
    }

    /** إشارة حد السرعة + سرعتك الحالية (تحت يسار، جنب زر التطبيقات) */
    private void addSpeedViews() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        box.setBackgroundResource(R.drawable.glass_bg);
        int bp = AppsHelper.dp(this, 9);
        box.setPadding(bp, bp, bp * 2, bp);

        tvLimit = new TextView(this);
        tvLimit.setBackgroundResource(R.drawable.speed_sign);
        tvLimit.setGravity(Gravity.CENTER);
        tvLimit.setTextColor(0xFF111111);
        tvLimit.setTextSize(20);
        tvLimit.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        tvLimit.setVisibility(View.GONE);
        int s = AppsHelper.dp(this, 58);
        box.addView(tvLimit, new LinearLayout.LayoutParams(s, s));

        LinearLayout sp = new LinearLayout(this);
        sp.setOrientation(LinearLayout.VERTICAL);
        sp.setGravity(Gravity.CENTER_HORIZONTAL);
        tvSpeed = new TextView(this);
        tvSpeed.setText("0");
        tvSpeed.setTextColor(0xFFEEF3FA);
        tvSpeed.setTextSize(30);
        tvSpeed.setIncludeFontPadding(false);
        TextView unit = new TextView(this);
        unit.setText("كم/س");
        unit.setTextColor(0xFF9FB2CC);
        unit.setTextSize(12);
        sp.addView(tvSpeed);
        sp.addView(unit);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = AppsHelper.dp(this, 12);
        box.addView(sp, lp);

        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.LEFT);
        flp.leftMargin = AppsHelper.dp(this, 12);
        flp.topMargin = AppsHelper.dp(this, 12);
        ((FrameLayout) findViewById(R.id.root)).addView(box, flp);

        tvCam = new TextView(this);
        tvCam.setTextColor(0xFFFFD34D);
        tvCam.setTextSize(16);
        tvCam.setVisibility(View.GONE);
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.LEFT);
        clp.leftMargin = AppsHelper.dp(this, 22);
        clp.topMargin = AppsHelper.dp(this, 102);
        ((FrameLayout) findViewById(R.id.root)).addView(tvCam, clp);
    }

    /** بنر الملاحة: يعرض اللي يكتبه هدهد (أو قوقل/ويز) في إشعار الملاحة */
    private void addNavBanner() {
        navBanner = new LinearLayout(this);
        navBanner.setOrientation(LinearLayout.HORIZONTAL);
        navBanner.setGravity(Gravity.CENTER_VERTICAL);
        navBanner.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        navBanner.setBackgroundResource(R.drawable.banner_bg);
        int p = AppsHelper.dp(this, 10);
        navBanner.setPadding(p, p, p, p);
        navBanner.setVisibility(View.GONE);

        navIcon = new ImageView(this);
        navIcon.setBackgroundResource(R.drawable.banner_icon_bg);
        int ip = AppsHelper.dp(this, 4);
        navIcon.setPadding(ip, ip, ip, ip);
        navIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int is = AppsHelper.dp(this, 40);
        navBanner.addView(navIcon, new LinearLayout.LayoutParams(is, is));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        navTitle = new TextView(this);
        navTitle.setTextColor(0xFFEEF3FA);
        navTitle.setTextSize(16);
        navTitle.setMaxLines(2);
        navTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        navText = new TextView(this);
        navText.setTextColor(0xFF9FB2CC);
        navText.setTextSize(13);
        navText.setMaxLines(2);
        navText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        navDist = new TextView(this);
        navDist.setTextColor(0xFFEEF3FA);
        navDist.setTextSize(22);
        navDist.setIncludeFontPadding(false);
        texts.addView(navDist);
        texts.addView(navTitle);
        texts.addView(navText);
        navTrack = new FrameLayout(this);
        navTrack.setBackgroundColor(0xFF2A3B55);
        navFill = new View(this);
        navFill.setBackgroundColor(0xFF5FA8FF);
        navTrack.addView(navFill, new FrameLayout.LayoutParams(0, FrameLayout.LayoutParams.MATCH_PARENT,
                Gravity.RIGHT));
        LinearLayout.LayoutParams trlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, AppsHelper.dp(this, 5));
        trlp.topMargin = AppsHelper.dp(this, 6);
        texts.addView(navTrack, trlp);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        tlp.setMarginStart(AppsHelper.dp(this, 10));
        navBanner.addView(texts, tlp);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                AppsHelper.dp(this, 270), FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.LEFT);
        lp.leftMargin = AppsHelper.dp(this, 14);
        lp.topMargin = AppsHelper.dp(this, 128);
        ((FrameLayout) findViewById(R.id.root)).addView(navBanner, lp);
        navBanner.setOnClickListener(v -> {
            String hh = AppsHelper.hudhud(this);
            if (hh != null) AppsHelper.launch(this, hh);
        });
    }

    /** يحوّل الأرقام العربية (٠١٢) لإنجليزية */
    private static String latinDigits(String s) {
        StringBuilder b = new StringBuilder(s.length());
        for (char ch : s.toCharArray()) {
            if (ch >= '٠' && ch <= '٩') b.append((char) ('0' + ch - '٠'));
            else if (ch >= '۰' && ch <= '۹') b.append((char) ('0' + ch - '۰'));
            else if (ch == '٫') b.append('.');
            else b.append(ch);
        }
        return b.toString();
    }

    @Override
    public void onNav(String title, String text, android.graphics.drawable.Drawable icon) {
        if (navBanner == null) return;
        String all = latinDigits(title + " " + text);
        String low = all.toLowerCase(Locale.US);

        // حد السرعة من هدهد (مثل: حد السرعة 80)
        java.util.regex.Matcher lm = java.util.regex.Pattern
                .compile("(?:حد السرعة|السرعة القصوى|speed limit)\\D{0,6}(\\d{2,3})").matcher(low);
        if (lm.find()) {
            hudhudLimit = Integer.parseInt(lm.group(1));
            showLimitSign(hudhudLimit, 0);
        }

        // المسافة (200 متر / 1.2 كم / 300 m)
        float meters = -1;
        String distLabel = "";
        String distRaw = "";
        java.util.regex.Matcher dm = java.util.regex.Pattern
                .compile("(\\d+(?:[.,]\\d+)?)\\s*(كم|كيلو|km|متر|م(?![\\u0600-\\u06FF])|m\\b)").matcher(low);
        if (dm.find()) {
            float v = Float.parseFloat(dm.group(1).replace(',', '.'));
            String u = dm.group(2);
            boolean km = u.startsWith("ك") || u.equals("km");
            meters = km ? v * 1000 : v;
            distLabel = dm.group(1) + (km ? " كم" : " م");
            distRaw = dm.group(0);
        }

        // نوع التنبيه من الكلمات
        int res = 0;
        boolean alertSound = false;
        String type = "";
        if (low.contains("كاميرا") || low.contains("ساهر") || low.contains("camera")) {
            res = R.drawable.nav_camera; alertSound = true; type = "cam";
        } else if (low.contains("مطب") || low.contains("مهدئ") || low.contains("bump")) {
            res = R.drawable.nav_bump; alertSound = true; type = "bump";
        } else if (low.contains("إشارة") || low.contains("اشارة") || low.contains("traffic light")) {
            res = R.drawable.nav_light; type = "light";
        } else if (low.contains("دوار") || low.contains("roundabout")) {
            res = R.drawable.nav_roundabout; type = "round";
        } else if (low.contains("يمين") || low.contains("right")) {
            res = R.drawable.nav_right; type = "right";
        } else if (low.contains("يسار") || low.contains("left")) {
            res = R.drawable.nav_left; type = "left";
        } else if (low.contains("تحذير") || low.contains("حادث") || low.contains("خطر")
                || low.contains("زحمة") || low.contains("warning")) {
            res = R.drawable.nav_warning; alertSound = true; type = "warn";
        } else if (low.contains("استمر") || low.contains("مباشر") || low.contains("straight")) {
            res = R.drawable.nav_straight; type = "straight";
        }

        if (icon != null) navIcon.setImageDrawable(icon);         // أيقونة هدهد نفسه إذا أرسلها
        else if (res != 0) navIcon.setImageResource(res);
        navIcon.setVisibility(icon != null || res != 0 ? View.VISIBLE : View.GONE);

        // النص بدون المسافة (لأنها صارت فوق كبيرة)
        String t = latinDigits(title), x = latinDigits(text);
        if (!distRaw.isEmpty()) {
            t = t.replace(distRaw, "").trim();
            x = x.replace(distRaw, "").trim();
        }
        navDist.setText(distLabel);
        navDist.setVisibility(distLabel.isEmpty() ? View.GONE : View.VISIBLE);
        navTitle.setText(t.isEmpty() ? x : t);
        navText.setText(t.isEmpty() ? "" : x);
        navText.setVisibility(t.isEmpty() || x.isEmpty() ? View.GONE : View.VISIBLE);

        // الشريط: يبدأ ممتلي ويقصر كل ما تقرّب من نفس التعليمة
        String key = type + "|" + (t.isEmpty() ? x : t).replaceAll("\\d", "");
        if (!key.equals(navKey) || meters > navStartM) {
            navKey = key;
            navStartM = meters;
        }
        if (meters >= 0 && navStartM > 0) {
            final float frac = Math.max(0f, Math.min(1f, meters / navStartM));
            navTrack.setVisibility(View.VISIBLE);
            navTrack.post(() -> {
                FrameLayout.LayoutParams flp = (FrameLayout.LayoutParams) navFill.getLayoutParams();
                flp.width = Math.round(navTrack.getWidth() * frac);
                navFill.setLayoutParams(flp);
            });
        } else {
            navTrack.setVisibility(View.GONE);
        }

        // صوت للكاميرا والمطب والتحذير (مرة وحدة لكل تنبيه)
        if (alertSound && !key.equals(lastNavAlertKey)) {
            lastNavAlertKey = key;
            cameraBeep();
        }
        navBanner.setVisibility(View.VISIBLE);
    }

    @Override
    public void onNavCleared() {
        if (navBanner != null) navBanner.setVisibility(View.GONE);
        hudhudLimit = 0;
        lastNavAlertKey = "";
        showLimitSign(AppsHelper.prefs(this).getInt("limit", 0),
                AppsHelper.prefs(this).getInt("fallbackLimit", 120));
    }

    private boolean hasNotificationAccess() {
        String flat = android.provider.Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return flat != null && flat.contains(getPackageName());
    }

    private void openNotificationAccess() {
        try {
            startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
        } catch (Exception e) {
            android.widget.Toast.makeText(this, "افتح الإعدادات ← الإشعارات ← الوصول للإشعارات",
                    android.widget.Toast.LENGTH_LONG).show();
        }
    }

    /** تنبيه الكاميرات الثابتة (احتياطي لهدهد) من بيانات OpenStreetMap */
    private void checkCameras(Location l) {
        if (!AppsHelper.prefs(this).getBoolean("camAlertOn", true)) {
            tvCam.setVisibility(View.GONE);
            return;
        }
        long now = System.currentTimeMillis();
        if (!camBusy && (lastCamFetch == null || lastCamFetch.distanceTo(l) > 2500
                || now - lastCamFetchTime > 15 * 60 * 1000)) {
            lastCamFetch = l;
            lastCamFetchTime = now;
            fetchCameras(l.getLatitude(), l.getLongitude());
        }
        float kmh = l.hasSpeed() ? l.getSpeed() * 3.6f : 0;
        double[] nearest = null;
        float nearestD = Float.MAX_VALUE;
        synchronized (cameras) {
            for (double[] cam : cameras) {
                Location cl = new Location("cam");
                cl.setLatitude(cam[0]);
                cl.setLongitude(cam[1]);
                float d = l.distanceTo(cl);
                if (d > 600) continue;
                // الكاميرا لازم تكون قدامك (مو وراك) والسيارة ماشية
                if (kmh < 15 || !l.hasBearing()) continue;
                float diff = Math.abs(((l.bearingTo(cl) - l.getBearing()) % 360 + 540) % 360 - 180);
                if (diff > 50) continue;
                if (d < nearestD) {
                    nearestD = d;
                    nearest = cam;
                }
            }
        }
        if (nearest == null) {
            tvCam.setVisibility(View.GONE);
            return;
        }
        int dist = Math.round(nearestD / 10f) * 10;
        tvCam.setText("⚠ كاميرا بعد " + dist + " م");
        tvCam.setVisibility(View.VISIBLE);
        String key = String.format(Locale.US, "%.5f,%.5f", nearest[0], nearest[1]);
        Long last = camAlerted.get(key);
        if (last == null || now - last > 5 * 60 * 1000) {
            camAlerted.put(key, now);
            cameraBeep();
        }
    }

    private void fetchCameras(double lat, double lng) {
        camBusy = true;
        new Thread(() -> {
            java.util.List<double[]> found = new java.util.ArrayList<>();
            HttpURLConnection c = null;
            try {
                String q = String.format(Locale.US,
                        "[out:json][timeout:15];(node(around:5000,%1$.6f,%2$.6f)[highway=speed_camera];"
                                + "node(around:5000,%1$.6f,%2$.6f)[enforcement=maxspeed];);out;", lat, lng);
                c = (HttpURLConnection) new URL("https://overpass-api.de/api/interpreter").openConnection();
                c.setConnectTimeout(8000);
                c.setReadTimeout(15000);
                c.setDoOutput(true);
                c.setRequestProperty("User-Agent", "CarHome/1.0");
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                try (OutputStream os = c.getOutputStream()) {
                    os.write(("data=" + URLEncoder.encode(q, "UTF-8")).getBytes("UTF-8"));
                }
                StringBuilder sb = new StringBuilder();
                try (InputStream is = c.getInputStream()) {
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = is.read(buf)) > 0) sb.append(new String(buf, 0, n, "UTF-8"));
                }
                JSONArray els = new JSONObject(sb.toString()).optJSONArray("elements");
                if (els != null) {
                    for (int i = 0; i < els.length(); i++) {
                        JSONObject e = els.getJSONObject(i);
                        if (e.has("lat")) found.add(new double[]{e.getDouble("lat"), e.getDouble("lon")});
                    }
                }
                synchronized (cameras) {
                    cameras.clear();
                    cameras.addAll(found);
                }
            } catch (Exception ignored) {
                lastCamFetchTime = 0; // نعيد المحاولة قريب
            } finally {
                if (c != null) c.disconnect();
            }
            camBusy = false;
        }).start();
    }

    /** صوت الكاميرا: نغمتين حادتين (مختلف عن بيب السرعة وصوت الإشعارات) */
    private void cameraBeep() {
        try {
            if (tone == null) {
                tone = new android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 100);
            }
            tone.startTone(android.media.ToneGenerator.TONE_CDMA_HIGH_PBX_SLS, 1200);
        } catch (Exception ignored) {
        }
    }

    private void updateSpeed(Location l) {
        int kmh = l.hasSpeed() ? Math.round(l.getSpeed() * 3.6f) : 0;
        tvSpeed.setText(String.valueOf(kmh));
        int streetLimit = AppsHelper.prefs(this).getInt("limit", 0);
        int fallback = AppsHelper.prefs(this).getInt("fallbackLimit", 120);
        int limit = hudhudLimit > 0 ? hudhudLimit : (streetLimit > 0 ? streetLimit : fallback);
        if (hudhudLimit > 0) showLimitSign(hudhudLimit, 0);
        else showLimitSign(streetLimit, fallback);
        boolean over = limit > 0 && kmh > limit + 2;
        tvSpeed.setTextColor(over ? 0xFFFF5A5F : 0xFFEEF3FA);
        // تنبيه صوتي إذا تعديت الحد، ويتكرر كل 8 ثواني ما دمت متعدي
        if (over && AppsHelper.prefs(this).getBoolean("speedAlertOn", true)
                && System.currentTimeMillis() - lastBeep > 8000) {
            lastBeep = System.currentTimeMillis();
            speedBeep();
        }

        // نسأل عن حد سرعة الشارع كل 12 ثانية إذا تحركنا أكثر من 40 متر
        long now = System.currentTimeMillis();
        if (!limitBusy && now - lastLimitTime > 12000
                && (lastLimitCheck == null || lastLimitCheck.distanceTo(l) > 40)) {
            lastLimitTime = now;
            lastLimitCheck = l;
            fetchSpeedLimit(l.getLatitude(), l.getLongitude());
        }
    }

    /** الإشارة: حد الشارع إذا معروف (أحمر)، وإلا الحد الاحتياطي اللي اخترته (باهت) */
    private void showLimitSign(int street, int fallback) {
        if (street > 0) {
            tvLimit.setText(String.valueOf(street));
            tvLimit.setAlpha(1f);
            tvLimit.setVisibility(View.VISIBLE);
        } else if (fallback > 0) {
            tvLimit.setText(String.valueOf(fallback));
            tvLimit.setAlpha(0.45f);
            tvLimit.setVisibility(View.VISIBLE);
        } else {
            tvLimit.setVisibility(View.GONE);
        }
    }

    private void chooseFallbackLimit() {
        final int[] vals = {80, 100, 120, 140, 0};
        String[] names = {"80", "100", "120", "140", "بدون (فقط حد الشارع)"};
        new android.app.AlertDialog.Builder(this)
                .setTitle("حد السرعة إذا حد الشارع غير معروف")
                .setItems(names, (d, w) -> {
                    AppsHelper.prefs(this).edit().putInt("fallbackLimit", vals[w]).apply();
                    showLimitSign(AppsHelper.prefs(this).getInt("limit", 0), vals[w]);
                })
                .show();
    }

    /** حد السرعة من بيانات OpenStreetMap (خدمة Overpass) */
    private void fetchSpeedLimit(double lat, double lng) {
        limitBusy = true;
        new Thread(() -> {
            int limit = 0;
            HttpURLConnection c = null;
            try {
                String q = String.format(Locale.US,
                        "[out:json][timeout:8];way(around:20,%.6f,%.6f)[highway][maxspeed];out tags 1;", lat, lng);
                c = (HttpURLConnection) new URL("https://overpass-api.de/api/interpreter").openConnection();
                c.setConnectTimeout(6000);
                c.setReadTimeout(8000);
                c.setDoOutput(true);
                c.setRequestProperty("User-Agent", "CarHome/1.0");
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                try (OutputStream os = c.getOutputStream()) {
                    os.write(("data=" + URLEncoder.encode(q, "UTF-8")).getBytes("UTF-8"));
                }
                StringBuilder sb = new StringBuilder();
                try (InputStream is = c.getInputStream()) {
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = is.read(buf)) > 0) sb.append(new String(buf, 0, n, "UTF-8"));
                }
                JSONArray els = new JSONObject(sb.toString()).optJSONArray("elements");
                if (els != null && els.length() > 0) {
                    String ms = els.getJSONObject(0).getJSONObject("tags").optString("maxspeed", "");
                    String digits = ms.replaceAll("[^0-9]", "");
                    if (!digits.isEmpty()) {
                        limit = Integer.parseInt(digits);
                        if (ms.contains("mph")) limit = Math.round(limit * 1.609f);
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
            final int fl = limit;
            runOnUiThread(() -> {
                AppsHelper.prefs(this).edit().putInt("limit", fl).apply();
                if (hudhudLimit == 0) showLimitSign(fl, AppsHelper.prefs(this).getInt("fallbackLimit", 120));
            });
            limitBusy = false;
        }).start();
    }

    /** سهم أزرق داخل دائرة بيضاء مثل سهم الملاحة */
    private static Bitmap makeArrow(int size) {
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float r = size / 2f;
        p.setColor(0xFFFFFFFF);
        c.drawCircle(r, r, r, p);
        p.setColor(0xFF2D7FF9);
        c.drawCircle(r, r, r * 0.82f, p);
        Path a = new Path();
        a.moveTo(r, r * 0.35f);
        a.lineTo(r * 1.45f, r * 1.5f);
        a.lineTo(r, r * 1.22f);
        a.lineTo(r * 0.55f, r * 1.5f);
        a.close();
        p.setColor(0xFFFFFFFF);
        c.drawPath(a, p);
        return b;
    }

    private void openNavigation() {
        String[] pkgs = {"com.google.android.apps.maps", "com.waze"};
        for (String pkg : pkgs) {
            if (getPackageManager().getLaunchIntentForPackage(pkg) != null) {
                AppsHelper.launch(this, pkg);
                return;
            }
        }
    }

    private void updateClock() {
        Date now = new Date();
        tvDay.setText(new SimpleDateFormat("EEEE", AR).format(now));
        // \u200E يثبّت الاتجاه من اليسار لليمين عشان ما تنقلب الساعة في الأجهزة العربية
        if (tvMin != null) {
            tvTime.setText(new SimpleDateFormat("hh", Locale.US).format(now));
            tvMin.setText(new SimpleDateFormat("mm", Locale.US).format(now));
        } else {
            tvTime.setText("\u200E" + new SimpleDateFormat("hh : mm", Locale.US).format(now));
        }
        String greg = new SimpleDateFormat("d MMMM yyyy", AR).format(now);
        String hijri = "";
        try {
            android.icu.util.ULocale ul = new android.icu.util.ULocale("ar_SA@calendar=islamic-umalqura");
            hijri = android.icu.text.DateFormat.getDateInstance(
                    android.icu.text.DateFormat.LONG, ul).format(now);
        } catch (Exception ignored) {
        }
        tvDate.setText(hijri.isEmpty() ? greg : hijri);
        updateNextPrayer();
    }

    private static boolean isRamadan() {
        try {
            android.icu.util.IslamicCalendar ic = new android.icu.util.IslamicCalendar();
            ic.setCalculationType(android.icu.util.IslamicCalendar.CalculationType.ISLAMIC_UMALQURA);
            return ic.get(android.icu.util.Calendar.MONTH) == 8;
        } catch (Exception e) {
            return false;
        }
    }

    /** أوقات الصلاة حسب موقع السيارة (الافتراضي جدة) بطريقة أم القرى */
    private void updateNextPrayer() {
        java.util.Calendar c = java.util.Calendar.getInstance();
        double lat = Double.parseDouble(AppsHelper.prefs(this).getString("lat", "21.5433"));
        double lng = Double.parseDouble(AppsHelper.prefs(this).getString("lng", "39.1728"));
        String key = c.get(java.util.Calendar.DAY_OF_YEAR) + "|" + Math.round(lat * 10) + "|" + Math.round(lng * 10);
        if (!key.equals(timesKey)) {
            double tz = java.util.TimeZone.getDefault().getOffset(c.getTimeInMillis()) / 3600000.0;
            times = PrayerTimes.compute(c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH) + 1,
                    c.get(java.util.Calendar.DAY_OF_MONTH), lat, lng, tz, isRamadan());
            timesKey = key;
            AdhanScheduler.schedule(this);
        }
        double now = c.get(java.util.Calendar.HOUR_OF_DAY) + c.get(java.util.Calendar.MINUTE) / 60.0
                + c.get(java.util.Calendar.SECOND) / 3600.0;
        int next = -1;
        for (int i = 0; i < times.length; i++) {
            if (i == 1) continue; // الشروق مو صلاة
            if (times[i] > now) {
                next = i;
                break;
            }
        }
        double at;
        double left;
        if (next == -1) {
            next = 0;
            at = times[0];
            left = times[0] + 24 - now;
        } else {
            at = times[next];
            left = times[next] - now;
        }
        tvNextName.setText(NAMES[next]);
        tvNextTime.setText(fmtTime(at));
        int lm = (int) Math.ceil(left * 60);
        tvNextLeft.setText(String.format(Locale.US, "بعد %d:%02d", lm / 60, lm % 60));
    }

    private static String fmtTime(double h) {
        int m = (int) Math.round(h * 60);
        m = ((m % 1440) + 1440) % 1440;
        int hh = m / 60;
        int h12 = hh % 12 == 0 ? 12 : hh % 12;
        return String.format(Locale.US, "%d:%02d %s", h12, m % 60, hh < 12 ? "ص" : "م");
    }

    private void requestPerms() {
        java.util.List<String> need = new java.util.ArrayList<>();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.ACCESS_FINE_LOCATION);
            need.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        if (android.os.Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                != PackageManager.PERMISSION_GRANTED) {
            need.add("android.permission.POST_NOTIFICATIONS");
        }
        if (!need.isEmpty()) {
            requestPermissions(need.toArray(new String[0]), REQ_PERMS);
        } else {
            startLocation();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        startLocation();
    }

    private void startLocation() {
        if (locationStarted) return;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        try {
            lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            Location best = null;
            for (String p : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
            if (best != null) onNewLocation(best);
            for (String p : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
                if (lm.isProviderEnabled(p)) {
                    lm.requestLocationUpdates(p, 1000, 2, locationListener, Looper.getMainLooper());
                }
            }
            locationStarted = true;
        } catch (SecurityException | IllegalArgumentException ignored) {
        }
    }

    private void onNewLocation(Location l) {
        if (tvSpeed != null) updateSpeed(l);
        if (tvCam != null) checkCameras(l);
        if (lastWeather == 0) fetchWeather();
        if (l.hasBearing() && l.getSpeed() > 1.5f) lastBearing = l.getBearing();
        if (map != null) {
            map.animateCamera(CameraUpdateFactory.newCameraPosition(new CameraPosition.Builder()
                    .target(new LatLng(l.getLatitude(), l.getLongitude()))
                    .zoom(16.5).tilt(55).bearing(lastBearing).build()), 900);
        }
        AppsHelper.prefs(this).edit()
                .putString("lat", String.valueOf(l.getLatitude()))
                .putString("lng", String.valueOf(l.getLongitude()))
                .apply();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(tick);
        if (mapView != null) mapView.onResume();
        handler.post(weatherTick);
        NavNotificationService.listener = this;
        if (slideshow != null) slideshow.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
        if (mapView != null) mapView.onPause();
        handler.removeCallbacks(weatherTick);
        if (slideshow != null) slideshow.stop();
    }

    @Override
    protected void onDestroy() {
        if (lm != null) lm.removeUpdates(locationListener);
        if (NavNotificationService.listener == this) NavNotificationService.listener = null;
        if (mapView != null) mapView.onDestroy();
        if (tone != null) tone.release();
        super.onDestroy();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mapView != null) mapView.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mapView != null) mapView.onStop();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        if (mapView != null) mapView.onLowMemory();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (mapView != null) mapView.onSaveInstanceState(out);
    }

    @Override
    public void onBackPressed() {
        // واجهة رئيسية: زر الرجوع ما يسوي شي
    }
}
