package com.turki.carhome;

import android.app.Notification;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.Locale;

/**
 * يقرأ إشعارات الملاحة (هدهد، وقوقل ماب، وويز) ويرسل محتواها للواجهة عشان تعرضه في البنر:
 * الانعطافات، والمسافة، وأي تحذير يكتبه التطبيق في إشعاره.
 */
public class NavNotificationService extends NotificationListenerService {

    public interface Listener {
        void onNav(String title, String text, Drawable icon);

        void onNavCleared();
    }

    static volatile Listener listener;
    private static String activeKey;
    private static final Handler main = new Handler(Looper.getMainLooper());

    static boolean isHudhud(String pkg) {
        return pkg.toLowerCase(Locale.US).contains("hudhud");
    }

    static boolean isNavApp(String pkg) {
        return isHudhud(pkg)
                || pkg.equals("com.google.android.apps.maps")
                || pkg.equals("com.waze");
    }

    @Override
    public void onListenerConnected() {
        AppsHelper.prefs(this).edit().putLong("listenerAt", System.currentTimeMillis()).apply();
        try {
            StatusBarNotification[] all = getActiveNotifications();
            if (all != null) {
                for (StatusBarNotification sbn : all) handle(sbn);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        handle(sbn);
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        if (sbn.getKey().equals(activeKey)) {
            activeKey = null;
            main.post(() -> {
                Listener l = listener;
                if (l != null) l.onNavCleared();
            });
        }
    }

    /** سجل آخر إشعارات تطبيقات الملاحة (عشان نعرف وش يكتب هدهد بالضبط) */
    private void log(String pkg, Notification n) {
        try {
            Bundle e = n.extras;
            StringBuilder sb = new StringBuilder();
            sb.append(new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date()))
                    .append("  ").append(pkg)
                    .append((n.flags & Notification.FLAG_ONGOING_EVENT) != 0 ? "  [ثابت]" : "")
                    .append("\n");
            for (String k : new String[]{Notification.EXTRA_TITLE, Notification.EXTRA_TEXT,
                    Notification.EXTRA_BIG_TEXT, Notification.EXTRA_SUB_TEXT, Notification.EXTRA_INFO_TEXT}) {
                CharSequence v = e.getCharSequence(k);
                if (v != null && v.length() > 0) sb.append(k.replace("android.", "")).append(": ").append(v).append("\n");
            }
            if (n.tickerText != null) sb.append("ticker: ").append(n.tickerText).append("\n");
            sb.append(n.getLargeIcon() != null ? "فيه أيقونة\n" : "").append(n.contentView != null ? "فيه تصميم مخصص\n" : "");
            android.content.SharedPreferences pr = AppsHelper.prefs(this);
            String old = pr.getString("navlog", "");
            String all = sb + "—————\n" + old;
            if (all.length() > 4000) all = all.substring(0, 4000);
            pr.edit().putString("navlog", all).apply();
        } catch (Exception ignored) {
        }
    }

    private void handle(StatusBarNotification sbn) {
        String pkg = sbn.getPackageName();
        if (!isNavApp(pkg)) return;
        Notification n = sbn.getNotification();
        log(pkg, n);
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        // قوقل ماب وويز: إشعار الملاحة الثابت بس. هدهد: كل إشعاراته (فيها التحذيرات)
        if (!isHudhud(pkg) && (n.flags & Notification.FLAG_ONGOING_EVENT) == 0) return;

        Bundle e = n.extras;
        CharSequence title = e.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence text = e.getCharSequence(Notification.EXTRA_BIG_TEXT);
        if (text == null) text = e.getCharSequence(Notification.EXTRA_TEXT);
        if (title == null && text == null) return;

        Drawable icon = null;
        try {
            Icon li = n.getLargeIcon();
            if (li != null) icon = li.loadDrawable(this);
        } catch (Exception ignored) {
        }

        activeKey = sbn.getKey();
        final String t = title != null ? title.toString() : "";
        final String x = text != null ? text.toString() : "";
        final Drawable ic = icon;
        main.post(() -> {
            Listener l = listener;
            if (l != null) l.onNav(t, x, ic);
        });
    }
}
