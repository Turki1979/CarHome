package com.turki.carhome;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/** صور تتبدل كل 10 ثواني بانتقال ناعم، ملوّنة بدرجات الكحلي وأطرافها متلاشية. */
public class PhotoSlideshow extends FadeFrameLayout {

    private static final long INTERVAL = 10000;

    private final ImageView a;
    private final ImageView b;
    private final TextView hint;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<Uri> photos = new ArrayList<>();
    private int index = -1;
    private boolean showingA = true;

    private final Runnable next = new Runnable() {
        @Override
        public void run() {
            showNext();
            handler.postDelayed(this, INTERVAL);
        }
    };

    public PhotoSlideshow(Context c) {
        super(c);
        ColorMatrixColorFilter navy = navyFilter();
        a = makeImage(c, navy);
        b = makeImage(c, navy);
        b.setAlpha(0f);
        addView(a, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        addView(b, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        hint = new TextView(c);
        hint.setText("اضغط مطوّلاً\nلإضافة صور");
        hint.setGravity(Gravity.CENTER);
        hint.setTextColor(0x809FB2CC);
        hint.setTextSize(13);
        addView(hint, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
    }

    private static ImageView makeImage(Context c, ColorMatrixColorFilter f) {
        ImageView iv = new ImageView(c);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setColorFilter(f);
        return iv;
    }

    /** يحوّل الصورة لدرجات من الكحلي الغامق إلى الأزرق الفاتح */
    private static ColorMatrixColorFilter navyFilter() {
        float[] dark = {0x0A, 0x14, 0x24};
        float[] light = {0xD6, 0xE4, 0xFA};
        float[] m = new float[20];
        float[] lum = {0.299f, 0.587f, 0.114f};
        for (int ch = 0; ch < 3; ch++) {
            float k = (light[ch] - dark[ch]) / 255f;
            m[ch * 5] = k * lum[0];
            m[ch * 5 + 1] = k * lum[1];
            m[ch * 5 + 2] = k * lum[2];
            m[ch * 5 + 3] = 0;
            m[ch * 5 + 4] = dark[ch];
        }
        m[18] = 1; // الشفافية كما هي
        return new ColorMatrixColorFilter(new ColorMatrix(m));
    }

    public void setPhotos(List<Uri> list) {
        photos.clear();
        photos.addAll(list);
        index = -1;
        hint.setVisibility(photos.isEmpty() ? VISIBLE : GONE);
        handler.removeCallbacks(next);
        if (!photos.isEmpty()) handler.post(next);
    }

    public void start() {
        handler.removeCallbacks(next);
        if (!photos.isEmpty()) handler.postDelayed(next, index < 0 ? 0 : INTERVAL);
    }

    public void stop() {
        handler.removeCallbacks(next);
    }

    private void showNext() {
        if (photos.isEmpty()) return;
        index = (index + 1) % photos.size();
        Bitmap bmp = load(photos.get(index));
        if (bmp == null) return;
        ImageView in = showingA ? b : a;
        ImageView out = showingA ? a : b;
        in.setImageBitmap(bmp);
        in.animate().alpha(1f).setDuration(1200).start();
        out.animate().alpha(0f).setDuration(1200).start();
        showingA = !showingA;
    }

    private Bitmap load(Uri uri) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream is = getContext().getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(is, null, o);
            }
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / sample > 900) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            try (InputStream is = getContext().getContentResolver().openInputStream(uri)) {
                return BitmapFactory.decodeStream(is, null, o2);
            }
        } catch (Exception e) {
            return null;
        }
    }
}
