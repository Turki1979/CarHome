package com.turki.carhome;

/**
 * حساب أوقات الصلاة محلياً (بدون إنترنت) بطريقة أم القرى:
 * الفجر 18.5 درجة، العصر حسب المذهب الشافعي/الجمهور، العشاء بعد المغرب بـ 90 دقيقة (120 في رمضان).
 * مبني على خوارزمية PrayTimes.org.
 */
public final class PrayerTimes {

    private double jDate;
    private double lat;

    private static double dsin(double d) { return Math.sin(Math.toRadians(d)); }
    private static double dcos(double d) { return Math.cos(Math.toRadians(d)); }
    private static double dtan(double d) { return Math.tan(Math.toRadians(d)); }
    private static double darcsin(double x) { return Math.toDegrees(Math.asin(x)); }
    private static double darccos(double x) { return Math.toDegrees(Math.acos(x)); }
    private static double darctan2(double y, double x) { return Math.toDegrees(Math.atan2(y, x)); }
    private static double darccot(double x) { return Math.toDegrees(Math.atan(1.0 / x)); }

    private static double fix(double a, double b) {
        a = a - b * Math.floor(a / b);
        return a < 0 ? a + b : a;
    }

    static double julian(int year, int month, int day) {
        if (month <= 2) {
            year -= 1;
            month += 12;
        }
        double a = Math.floor(year / 100.0);
        double b = 2 - a + Math.floor(a / 4.0);
        return Math.floor(365.25 * (year + 4716)) + Math.floor(30.6001 * (month + 1)) + day + b - 1524.5;
    }

    /** يرجع [الميل، معادلة الزمن] */
    private static double[] sunPosition(double jd) {
        double d = jd - 2451545.0;
        double g = fix(357.529 + 0.98560028 * d, 360);
        double q = fix(280.459 + 0.98564736 * d, 360);
        double l = fix(q + 1.915 * dsin(g) + 0.020 * dsin(2 * g), 360);
        double e = 23.439 - 0.00000036 * d;
        double ra = darctan2(dcos(e) * dsin(l), dcos(l)) / 15.0;
        double eqt = q / 15.0 - fix(ra, 24);
        double decl = darcsin(dsin(e) * dsin(l));
        return new double[]{decl, eqt};
    }

    private double midDay(double t) {
        double eqt = sunPosition(jDate + t)[1];
        return fix(12 - eqt, 24);
    }

    private double sunAngleTime(double angle, double t, boolean ccw) {
        double decl = sunPosition(jDate + t)[0];
        double noon = midDay(t);
        double tt = darccos((-dsin(angle) - dsin(decl) * dsin(lat)) / (dcos(decl) * dcos(lat))) / 15.0;
        return noon + (ccw ? -tt : tt);
    }

    private double asrTime(double factor, double t) {
        double decl = sunPosition(jDate + t)[0];
        double angle = -darccot(factor + dtan(Math.abs(lat - decl)));
        return sunAngleTime(angle, t, false);
    }

    /**
     * يرجع الأوقات بالساعات (مثلاً 4.75 = 4:45) بالترتيب:
     * الفجر، الشروق، الظهر، العصر، المغرب، العشاء
     */
    public static double[] compute(int year, int month, int day, double lat, double lng,
                                   double timezone, boolean ramadan) {
        PrayerTimes p = new PrayerTimes();
        p.lat = lat;
        p.jDate = julian(year, month, day) - lng / (15 * 24.0);

        double fajr = p.sunAngleTime(18.5, 5 / 24.0, true);
        double sunrise = p.sunAngleTime(0.833, 6 / 24.0, true);
        double dhuhr = p.midDay(12 / 24.0);
        double asr = p.asrTime(1, 13 / 24.0);
        double maghrib = p.sunAngleTime(0.833, 18 / 24.0, false);

        double adj = timezone - lng / 15.0;
        double[] r = new double[6];
        r[0] = fajr + adj;
        r[1] = sunrise + adj;
        r[2] = dhuhr + adj;
        r[3] = asr + adj;
        r[4] = maghrib + adj;
        r[5] = r[4] + (ramadan ? 2.0 : 1.5);
        return r;
    }
}
