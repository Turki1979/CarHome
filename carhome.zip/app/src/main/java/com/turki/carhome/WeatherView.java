package com.turki.carhome;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;

/** ودجت طقس متحرك: شمس تدور، قمر ونجوم تلمع، غيوم تتحرك، مطر ينزل، برق. */
public class WeatherView extends View {

    static final int CLEAR = 0, PARTLY = 1, CLOUDY = 2, FOG = 3, RAIN = 4, STORM = 5;

    private int kind = CLEAR;
    private boolean day = true;
    private String temp = "--°";
    private String desc = "";
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final long start = SystemClock.uptimeMillis();

    public WeatherView(Context c) {
        this(c, null);
    }

    public WeatherView(Context c, AttributeSet a) {
        super(c, a);
    }

    /** code حسب تصنيف WMO اللي يرجعه Open-Meteo */
    public void setWeather(int code, boolean isDay, double t) {
        day = isDay;
        temp = Math.round(t) + "°";
        if (code == 0) {
            kind = CLEAR;
            desc = "صافي";
        } else if (code == 1) {
            kind = PARTLY;
            desc = "صافي غالباً";
        } else if (code == 2) {
            kind = PARTLY;
            desc = "غائم جزئياً";
        } else if (code == 3) {
            kind = CLOUDY;
            desc = "غائم";
        } else if (code == 45 || code == 48) {
            kind = FOG;
            desc = "ضباب";
        } else if (code >= 95) {
            kind = STORM;
            desc = "عاصفة رعدية";
        } else if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) {
            kind = RAIN;
            desc = "مطر";
        } else {
            kind = CLOUDY;
            desc = "غائم";
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float t = (SystemClock.uptimeMillis() - start) / 1000f;
        float h = getHeight();
        float w = getWidth();
        if (h <= 0) return;

        if (h > w * 0.8f) {
            // وضع عمودي (في العمود اليمين): أيقونة كبيرة، تحتها الحرارة، تحتها الوصف
            float s = Math.min(w, h);
            drawIcon(c, w / 2f, h * 0.32f, s * 0.17f, t);
            p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER);
            p.setColor(0xFFEEF3FA);
            p.setTextSize(Math.min(h * 0.24f, w * 0.34f));
            c.drawText(temp, w / 2f, h * 0.76f, p);
            p.setColor(0xFF9FB2CC);
            p.setTextSize(Math.min(h * 0.1f, w * 0.13f));
            c.drawText(desc, w / 2f, h * 0.92f, p);
            p.setTextAlign(Paint.Align.LEFT);
            postInvalidateOnAnimation();
            return;
        }

        // نحسب عرض المحتوى عشان نخليه في النص
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(h * 0.42f);
        float tempW = p.measureText(temp);
        p.setTextSize(h * 0.22f);
        float descW = p.measureText(desc);
        float textW = Math.max(tempW, descW);
        float iconS = h;
        float gap = h * 0.15f;
        float x0 = (w - (iconS + gap + textW)) / 2f;

        drawIcon(c, x0 + iconS / 2f, h / 2f, h * 0.2f, t);

        float tx = x0 + iconS + gap;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFEEF3FA);
        p.setTextSize(h * 0.42f);
        c.drawText(temp, tx, h * 0.52f, p);
        p.setColor(0xFF9FB2CC);
        p.setTextSize(h * 0.22f);
        c.drawText(desc, tx, h * 0.85f, p);

        postInvalidateOnAnimation();
    }

    private void drawIcon(Canvas c, float cx, float cy, float r, float t) {
        switch (kind) {
            case CLEAR:
                if (day) sun(c, cx, cy, r, t);
                else moon(c, cx, cy, r, t);
                break;
            case PARTLY:
                if (day) sun(c, cx - r * 0.5f, cy - r * 0.4f, r * 0.8f, t);
                else moon(c, cx - r * 0.5f, cy - r * 0.4f, r * 0.8f, t);
                cloud(c, cx + r * 0.3f + (float) Math.sin(t * 0.8) * r * 0.15f, cy + r * 0.4f, r, 0xFFDCE6F2);
                break;
            case CLOUDY:
                cloud(c, cx - r * 0.4f + (float) Math.sin(t * 0.6) * r * 0.2f, cy - r * 0.3f, r * 0.8f, 0xFF9FB2CC);
                cloud(c, cx + r * 0.2f + (float) Math.sin(t * 0.8 + 1) * r * 0.2f, cy + r * 0.3f, r, 0xFFDCE6F2);
                break;
            case FOG:
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeWidth(r * 0.22f);
                for (int i = 0; i < 3; i++) {
                    float off = (float) Math.sin(t * 1.2 + i) * r * 0.35f;
                    p.setColor(0xFFDCE6F2);
                    p.setAlpha(140 + i * 40);
                    float y = cy - r * 0.6f + i * r * 0.6f;
                    c.drawLine(cx - r * 1.1f + off, y, cx + r * 1.1f + off, y, p);
                }
                break;
            case RAIN:
            case STORM:
                cloud(c, cx, cy - r * 0.35f, r, 0xFFB8C7DA);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeWidth(r * 0.12f);
                p.setColor(0xFF5FA8FF);
                for (int i = 0; i < 4; i++) {
                    float fall = ((t * 1.6f + i * 0.27f) % 1f);
                    float x = cx - r * 0.75f + i * r * 0.5f;
                    float y = cy + r * 0.25f + fall * r * 0.9f;
                    p.setAlpha((int) (255 * (1 - fall)));
                    c.drawLine(x, y, x - r * 0.12f, y + r * 0.3f, p);
                }
                p.setAlpha(255);
                if (kind == STORM && (t % 3f) < 0.18f) {
                    Path bolt = new Path();
                    bolt.moveTo(cx + r * 0.1f, cy);
                    bolt.lineTo(cx - r * 0.25f, cy + r * 0.6f);
                    bolt.lineTo(cx + r * 0.05f, cy + r * 0.6f);
                    bolt.lineTo(cx - r * 0.2f, cy + r * 1.2f);
                    bolt.lineTo(cx + r * 0.45f, cy + r * 0.45f);
                    bolt.lineTo(cx + r * 0.15f, cy + r * 0.45f);
                    bolt.close();
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(0xFFFFD34D);
                    c.drawPath(bolt, p);
                }
                break;
        }
        p.setAlpha(255);
    }

    private void sun(Canvas c, float cx, float cy, float r, float t) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x33FFC94D);
        c.drawCircle(cx, cy, r * (1.25f + 0.08f * (float) Math.sin(t * 2)), p);
        p.setColor(0xFFFFC94D);
        c.drawCircle(cx, cy, r * 0.75f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(r * 0.14f);
        c.save();
        c.rotate(t * 25f, cx, cy);
        for (int i = 0; i < 8; i++) {
            c.drawLine(cx, cy - r * 1.05f, cx, cy - r * 1.4f, p);
            c.rotate(45f, cx, cy);
        }
        c.restore();
    }

    private void moon(Canvas c, float cx, float cy, float r, float t) {
        Path a = new Path();
        a.addCircle(cx, cy, r, Path.Direction.CW);
        Path b = new Path();
        b.addCircle(cx + r * 0.5f, cy - r * 0.35f, r * 0.85f, Path.Direction.CW);
        a.op(b, Path.Op.DIFFERENCE);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFF3E7B3);
        c.drawPath(a, p);
        float[][] stars = {{1.2f, -0.9f}, {1.5f, 0.3f}, {0.9f, 0.9f}};
        for (int i = 0; i < stars.length; i++) {
            int alpha = (int) (128 + 127 * Math.sin(t * 2.2 + i * 2));
            p.setColor(0xFFFFFFFF);
            p.setAlpha(Math.max(30, alpha));
            c.drawCircle(cx + stars[i][0] * r, cy + stars[i][1] * r, r * 0.09f, p);
        }
        p.setAlpha(255);
    }

    private void cloud(Canvas c, float cx, float cy, float r, int color) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        c.drawCircle(cx - r * 0.55f, cy + r * 0.1f, r * 0.45f, p);
        c.drawCircle(cx, cy - r * 0.15f, r * 0.62f, p);
        c.drawCircle(cx + r * 0.55f, cy + r * 0.1f, r * 0.45f, p);
        c.drawRect(cx - r * 0.55f, cy + r * 0.1f, cx + r * 0.55f, cy + r * 0.55f, p);
    }
}
